
import os
import joblib
import numpy as np
from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

MODEL_DIR = os.path.join(app.root_path, "models")

ridge_model = joblib.load(
    os.path.join(MODEL_DIR, "ridge_model.pkl")
)
lasso_model = joblib.load(
    os.path.join(MODEL_DIR, "lasso_model.pkl")
)

FEATURES = [
    "PM2.5 (Âµg/mÂ³)",
    "PM10 (Âµg/mÂ³)",
    "NO2 (Âµg/mÂ³)",
    "NH3 (Âµg/mÂ³)",
    "SO2 (Âµg/mÂ³)",
    "CO (mg/mÂ³)",
    "Ozone (Âµg/mÂ³)"
]


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/api/predict", methods=["POST"])
def predict():
    data = request.get_json(silent=True) or {}

    try:
        values = [float(data[name]) for name in FEATURES]

        if not np.all(np.isfinite(values)) or any(v < 0 for v in values):
            return jsonify({"error": "Enter valid, non-negative pollutant values."}), 400

        row = np.array(values).reshape(1, -1)

        ridge = float(ridge_model.predict(row)[0])
        lasso = float(lasso_model.predict(row)[0])

        return jsonify({
            "ridge": round(float(np.clip(ridge, 0, 500)), 2),
            "lasso": round(float(np.clip(lasso, 0, 500)), 2),
            "average": round(float(np.clip((ridge + lasso) / 2, 0, 500)), 2),
            "note": "Simplified demo index, not official measured AQI."
        })

    except (KeyError, TypeError, ValueError):
        return jsonify({
            "error": "Send all seven pollutant values as numbers."
        }), 400

if __name__ == "__main__":
    app.run(debug=True)

